public class CONSTANTS {
    final int SCREENWIDTH = 1900;
    final int SCREENHEIGHT = 1200;
    final int PANELWIDTH = SCREENWIDTH/2;
    final int PANELHEIGHT = SCREENHEIGHT;
    final int BUTTONWIDTH = PANELWIDTH/6;
    final int BUTTONHEIGHT = PANELWIDTH/6;
}